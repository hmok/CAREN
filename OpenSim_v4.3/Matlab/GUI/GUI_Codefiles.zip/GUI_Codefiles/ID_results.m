%% to plot muscle forces in 3 gait cycle at least

% function [aveSO, aveIK, aveID, aveGRF] = muscle_Forces(source, trials)
function [aveID, IDGaitCycle, aveIDNorm, IDGaitCycleNorm] = ID_results(source, trials, joint, side)

% averaging in 7s considering the gait cycles (final resutls is in one cycle)
% just one trial e.g W101 so there is another
% code for IK, ID, and So that averages for all 4*7s or in 2min trial. So
% this should not be mistaken.

%example
% 
% 1. 
% addpath('C:\Users\mhossein\Documents\OpenSim\4.0\Code\Matlab');
% %2. 
% source = 'C:\Users\mhossein\OneDrive - The University of Melbourne\Projects\TargetSearch\SH';
% %3. 
% %trials = {'S+T01','S+T02','S+T03','S+T04', ...
% %'W101','W102','W103','W104',...
% %    'W1+T01','W1+T02','W1+T03','W1+T04',...
% %    'W201','W202','W203','W204',...
% %%    'W2+T01','W2+T02','W2+T03','W2+T04',...
% %    'W301','W302','W303','W304',...
% %    'W3+T01','W3+T02','W3+T03','W3+T04'};
% %4. joints = 'lknee', 'rknee',
% %'lankle','rankle','lhipflex','rhipflex','lhipAd','rhipAd','lhipRot', 'rhipRot'
% %muscle = 'rankle'
% %5. 
% [aveID, IDGaitCycle, aveIDNorm, IDGaitCycleNorm] = ID_results(source,{'W1+R+DEC'},'rhipRot','left');
% %
% figure
% plot(aveIK);hold on;stdshade(IKGaitCycle',.1,'r')
%% example for 4*7s e.g. W101 to 04

% joint = 'lankle';side='right';
% subplot(2,3,1)
% [aveID1, IDGaitCycle] = ID_results(source,{'W101'},joint,side);
% subplot(2,3,2)
% [aveID2, IDGaitCycle] = ID_results(source,{'W102'},joint,side);
% subplot(2,3,3)
% [aveID3, IDGaitCycle] = ID_results(source,{'W103'},joint,side);
% subplot(2,3,4)
% [aveID4, IDGaitCycle] = ID_results(source,{'W104'},joint,side);
% 
% a=[aveID1,aveID2,aveID3,aveID4];
% subplot(2,3,5)
% plot(mean(a,2))
% stdshade(a')

% figure
% %plot on top of each other or one after the other with diff colors
% subplot(2,2,1)
% plot(muscleForceGaitCycle(:,1))
% subplot(2,2,2)
% plot(muscleForceGaitCycle(:,2))
% subplot(2,2,3)
% plot(muscleForceGaitCycle(:,3))
% subplot(2,2,4)
% plot(muscleForceGaitCycle(:,4))
% figure
% %to get one after the other with diff colors
% a=[1:101]
% hold on
% k=0;
% for i=1:length(muscleForceGaitCycle(1,:))
% plot(a+k,muscleForceGaitCycle(:,i))
% k=k+100;
% end
%% TODO
% get gaitevetn and its trial and find IK aver and write it for aveIK and
% so on
% need to write a funciton that gets just trial e.g. SH, and then spit out IK, 
% acall this aveMuscle force and then put it in Maltab folder and reccall
% it when needed


%% based on biomecognition file


muscle =joint; % cos I used muscle-force.m as the basis for this so I may just cahnge muscle to join..

load(fullfile(source, 'DFLOW\dflow.mat'))
load(fullfile(source, 'trcResults\gaitEvents.mat'))
load(fullfile(source, 'allSubjData.mat'));
for i=1:length(allSubjData)
   trialsall(i) =  (allSubjData(i).name);
end
% trials = {'S+T01','S+T02','S+T03','S+T04', ...
% 'W101','W102','W103','W104',...
%     'W1+T01','W1+T02','W1+T03','W1+T04',...
%     'W201','W202','W203','W204',...
%     'W2+T01','W2+T02','W2+T03','W2+T04',...
%     'W301','W302','W303','W304',...
%     'W3+T01','W3+T02','W3+T03','W3+T04'};

% load all the data GRF, muscles, mos, etc
load(fullfile(source,'grfResults\GRFs.mat'))
load(fullfile(source,'SOResults\SOs.mat'))
load(fullfile(source,'IDResults\IDs.mat'))
load(fullfile(source,'IKResults\IKs.mat'))
load(fullfile(source,'trcResults\gaitEvents.mat'))
load(fullfile(source,'trcResults\gaitUtils.mat'))

trialsUtils= gaitUtils.trialNames;
fields = fieldnames(GRFs(2).data);
for i = 1:length(GRFs)
    trials2{i}= GRFs(i).name;
%    trialsEvent{i}= gaitEvents(i).name;
   
end

for i = 1:length(gaitEvents)
%     trials2{i}= GRFs(i).name;
   trialsEvent{i}= gaitEvents(i).name;
   
end

for i = 1:length(IDs)
 
    trialsID{i}= extractBefore(IDs(i).name,'_');
    
end


for i = 1:length(IKs)
   
    trialsIK{i}= extractBefore(IKs(i).name,'_');
   
end


for i = 1:length(SOs)
   
    try 
    
    trialsSO{i}=  extractBefore(SOs(i).name,'_');
    
    catch 
        fprintf('Inconsistent data in iteration %s, skipped.\n', i);
    end
end

for j=1:length(trials)
% 1. load vars{1} e.g. vGRF load GRFs

% load(fullfile(source,'grfResults\GRFs.mat'))

a=21;
[ind, missTrials]=trialIndexFinder(string(trials{j}),trials2);
%get gaitEvnts trials from all
[indEvent, ~]=trialIndexFinder(string(trials{j}),trialsEvent);
%get gaitutils trials from all
[indUtils, ~]=trialIndexFinder(string(trials{j}),trialsEvent);
try 
[indSO, missTrialsSO]=trialIndexFinder(string(trials{j}),trialsSO);
catch 
    print('chcek later')
end
try
[indID, missTrialsID]=trialIndexFinder(string(trials{j}),trialsID);
catch 
    print('chcek later')
end
try
[indIK, missTrialsIK]=trialIndexFinder(string(trials{j}),trialsIK);
catch 
    print('chcek later')
end



% all all muscles etc needed here
% [muscleforce] = muslceForces(SOs, string(trials{j}) , 'lquad'); % take this as input
%%
% [muscleforce] = muslceForces(SOs, string(trials{j}) , muscle); % take this as input

%% get the fields of SO
fields = fieldnames(IDs(2).data);
for i=1:length(IDs)
trials1(i) = string(extractBefore(IDs(i).name,'_'));
end

% %joints = 'lknee', 'rknee',
% %'lankle','rankle','lhip','rhip','lhipAd','rhipAd','lhipRo', 'rhipRo'


switch joint
    case 'rknee'
        mm = {'knee_angle_r_moment'};
    case 'lknee'
        mm = {'knee_angle_l_moment'};
    case 'rankle'
        mm = {'ankle_angle_r_moment'};
    case 'lankle'
        mm = {'ankle_angle_l_moment'};
    case 'rhipflex'
        mm = {'hip_flexion_r_moment'};
    case 'lhipflex'
        mm = {'hip_flexion_l_moment'};
    case 'rhipAd'
        mm = {'hip_adduction_r_moment'};
    case 'lhipAd'
        mm = {'hip_adduction_l_moment'};
    case 'rhipRot'
        mm = {'hip_rotation_r_moment'};
    case 'lhipRot'
        mm = {'hip_rotation_l_moment'};
%     case 'rTAs'
%         mm = {'tib_ant_r'};
%     case 'lTAs'
%         mm = {'tib_ant_l'};
end

[indmm, ~]=trialIndexFinder(string(mm),fields);
try 
[ind, ~]=trialIndexFinder(string(trials),trials1);
IDGaitCycle = 0;

for i = 1:length(indmm)
    Buff(:,i) = IDs(ind).data.(string(mm(i)));
end
IDGait = sum(Buff,2);
        
catch 
    'check this later'
    IDGait = NaN;
end



%%
% [aveMuscleForce, muscleForceGaitCycle] = muscle_Forces(source,'W101');
% just for an exmapl then compelte
 
switch side
    case 'left'
        ind = gaitEvents(ind).data.HSLocL*100;
        for h=1:length(ind)-1
            try 
            MF(:,h)=ZeroTo100(IDGait(round(ind(h)):round(ind(h+1))),IDGait(round(ind(h)):round(ind(h+1))),100);
            catch 
                MF(:,h)=nan;
                continue
            end
        end
        IDGaitCycle = MF;
        aveID = mean(MF,2, 'omitnan');
        
%         plot([0:100],aveMuscleForce)
        
    case 'right'
        ind = gaitEvents(ind).data.HSLocR*100;
        for h=1:length(ind)-1
            try
            MF(:,h)=ZeroTo100(IDGait(round(ind(h)):round(ind(h+1))),IDGait(round(ind(h)):round(ind(h+1))),100);
            catch
            MF(:,h)=nan;
                continue
            end
        end
        
IDGaitCycle = MF;
aveID = mean(MF,2, 'omitnan');
        % plot([0:100],aveMuscleForce)
end

end

out=regexp(source,'\','split');
cmpr = out(end);
if ~isempty(out(end))
    cmpr = out(end-1);
end

index = find(strcmp(trialsall, cmpr)==1);
mass=allSubjData(2).data.weight;
IDGaitCycleNorm = IDGaitCycle./(mass*9.8);
aveIDNorm = aveID./(mass*9.8);



subplot(2,1,1);plot(aveID);hold on;stdshade(IDGaitCycle',.1,'r');title('Not normalized')
subplot(2,1,2);plot(aveIDNorm);hold on;stdshade(IDGaitCycleNorm',.1,'r');title('normalized')

