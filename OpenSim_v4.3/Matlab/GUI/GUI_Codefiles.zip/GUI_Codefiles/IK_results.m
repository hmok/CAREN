%% to plot muscle forces in 3 gait cycle at least

% function [aveSO, aveIK, aveID, aveGRF] = muscle_Forces(source, trials)
function [aveIK, IKGaitCycle] = IK_results(source, trials, joint, side)


%example
% 
% 1. 
% addpath('C:\Users\mhossein\Documents\OpenSim\4.0\Code\Matlab');
% %2. 
% source = 'C:\Users\mhossein\OneDrive - The University of Melbourne\Projects\TargetSearch\SH\';
% %3. 
% %trials = {'S+T01','S+T02','S+T03','S+T04', ...
% %'W101','W102','W103','W104',...
% %    'W1+T01','W1+T02','W1+T03','W1+T04',...
% %    'W201','W202','W203','W204',...
% %%    'W2+T01','W2+T02','W2+T03','W2+T04',...
% %    'W301','W302','W303','W304',...
% %    'W3+T01','W3+T02','W3+T03','W3+T04'};
% %4. joints = 'lknee', 'rknee',
% %'lankle','rankle','lhipflex','rhipflex','lhipAd','rhipAd','lhipRot', 'rhipRot'
% %muscle = 'rankle'
% %5. 
% [aveIK, IKGaitCycle] = IK_results(source,{'W1+R+DEC'},'rhipRot','left');
% %
% figure
% plot(aveIK);
% hold on;
% stdshade(IKGaitCycle',.1,'r')

% figure
% %plot on top of each other or one after the other with diff colors
% subplot(2,2,1)
% plot(muscleForceGaitCycle(:,1))
% subplot(2,2,2)
% plot(muscleForceGaitCycle(:,2))
% subplot(2,2,3)
% plot(muscleForceGaitCycle(:,3))
% subplot(2,2,4)
% plot(muscleForceGaitCycle(:,4))
% figure
% %to get one after the other with diff colors
% a=[1:101]
% hold on
% k=0;
% for i=1:length(muscleForceGaitCycle(1,:))
% plot(a+k,muscleForceGaitCycle(:,i))
% k=k+100;
% end
%% TODO
% get gaitevetn and its trial and find IK aver and write it for aveIK and
% so on
% need to write a funciton that gets just trial e.g. SH, and then spit out IK, 
% acall this aveMuscle force and then put it in Maltab folder and reccall
% it when needed


%% based on biomecognition file


muscle =joint; % cos I used muscle-force.m as the basis for this so I may just cahnge muscle to join..

load(fullfile(source, 'DFLOW\dflow.mat'))
load(fullfile(source, 'grfResults\gaitEvents.mat'))
% trials = {'S+T01','S+T02','S+T03','S+T04', ...
% 'W101','W102','W103','W104',...
%     'W1+T01','W1+T02','W1+T03','W1+T04',...
%     'W201','W202','W203','W204',...
%     'W2+T01','W2+T02','W2+T03','W2+T04',...
%     'W301','W302','W303','W304',...
%     'W3+T01','W3+T02','W3+T03','W3+T04'};

% load all the data GRF, muscles, mos, etc
load(fullfile(source,'grfResults\GRFs.mat'))
load(fullfile(source,'SOResults\SOs.mat'))
load(fullfile(source,'IDResults\IDs.mat'))
load(fullfile(source,'IKResults\IKs.mat'))
load(fullfile(source,'grfResults\gaitEvents.mat'))
load(fullfile(source,'trcResults\gaitUtils.mat'))
import org.opensim.modeling.*
trialsUtils= gaitUtils.trialNames;
fields = fieldnames(GRFs(1).data);
for i = 1:length(GRFs)
    trials2{i}= GRFs(i).name;
%    trialsEvent{i}= gaitEvents(i).name;
   
end

for i = 1:length(gaitEvents)
%     trials2{i}= GRFs(i).name;
   trialsEvent{i}= gaitEvents(i).name;
   
end

for i = 1:length(IDs)
 
    trialsID{i}= extractBefore(IDs(i).name,'_');
    
end


for i = 1:length(IKs)
   
    trialsIK{i}= extractBefore(IKs(i).name,'_');
   
end


for i = 1:length(SOs)
   
    try 
    
    trialsSO{i}=  extractBefore(SOs(i).name,'_');
    
    catch 
        fprintf('Inconsistent data in iteration %s, skipped.\n', i);
    end
end

for j=1:length(trials)
% 1. load vars{1} e.g. vGRF load GRFs

% load(fullfile(source,'grfResults\GRFs.mat'))

a=21;
[ind, missTrials]=trialIndexFinder(string(trials{j}),trials2);
%get gaitEvnts trials from all
[indEvent, ~]=trialIndexFinder(string(trials{j}),trialsEvent);
%get gaitutils trials from all
[indUtils, ~]=trialIndexFinder(string(trials{j}),trialsEvent);
try 
[indSO, missTrialsSO]=trialIndexFinder(string(trials{j}),trialsSO);
catch 
    print('chcek later')
end
try
[indID, missTrialsID]=trialIndexFinder(string(trials{j}),trialsID);
catch 
    print('chcek later')
end
try
[indIK, missTrialsIK]=trialIndexFinder(string(trials{j}),trialsIK);
catch 
    print('chcek later')
end



% all all muscles etc needed here
% [muscleforce] = muslceForces(SOs, string(trials{j}) , 'lquad'); % take this as input
%%
% [muscleforce] = muslceForces(SOs, string(trials{j}) , muscle); % take this as input

%% get the fields of SO
fields = fieldnames(IKs(2).data);
for i=1:length(IKs)
trials1(i) = string(extractBefore(IKs(i).name,'_'));
end

% %joints = 'lknee', 'rknee',
% %'lankle','rankle','lhip','rhip','lhipAd','rhipAd','lhipRo', 'rhipRo'


switch joint
    case 'rknee'
        mm = {'knee_angle_r'};
    case 'lknee'
        mm = {'knee_angle_l'};
    case 'rankle'
        mm = {'ankle_angle_r'};
    case 'lankle'
        mm = {'ankle_angle_l'};
    case 'rhipflex'
        mm = {'hip_flexion_r'};
    case 'lhipflex'
        mm = {'hip_flexion_l'};
    case 'rhipAd'
        mm = {'hip_adduction_r'};
    case 'lhipAd'
        mm = {'hip_adduction_l'};
    case 'rhipRot'
        mm = {'hip_rotation_r'};
    case 'lhipRot'
        mm = {'hip_rotation_l'};
        case 'pelvisTilt'
        mm = {'pelvis_tilt'};
    case 'lumbarExt'
        mm = {'lumbar_extension'};
%     case 'rTAs'
%         mm = {'tib_ant_r'};
%     case 'lTAs'
%         mm = {'tib_ant_l'};
end

[indmm, ~]=trialIndexFinder(string(mm),fields);
try 
[ind, ~]=trialIndexFinder(string(trials),trials1);
IKGaitCycle = 0;

for i = 1:length(indmm)
    Buff(:,i) = IKs(ind).data.(string(mm(i)));
end
IKGait = sum(Buff,2);
        
catch 
    'check this later'
    IKGait = NaN;
end



%%
% [aveMuscleForce, muscleForceGaitCycle] = muscle_Forces(source,'W101');
% just for an exmapl then compelte
MF = [];
switch side
    case 'left'
        gaitEvents(ind).name
        ind = gaitEvents(ind).data.HSLocL*100;
        for h=1:length(ind)-1
            try 
            MF(:,h)=ZeroTo100(IKGait(round(ind(h)):round(ind(h+1))),IKGait(round(ind(h)):round(ind(h+1))),100);
            catch 
                MF(:,h)=nan;
                continue
            end
        end
        IKGaitCycle = MF;
        aveIK = mean(MF,2, 'omitnan');
        
%         plot([0:100],aveMuscleForce)
        
    case 'right'
        ind = gaitEvents(ind).data.HSLocR*100;
        for h=1:length(ind)-1
            try
            MF(:,h)=ZeroTo100(IKGait(round(ind(h)):round(ind(h+1))),IKGait(round(ind(h)):round(ind(h+1))),100);
            catch
            MF(:,h)=nan;
                continue
            end
        end
        
IKGaitCycle = MF;
aveIK = mean(MF,2, 'omitnan');
        % plot([0:100],aveMuscleForce)
end

end

plot(aveIK);hold on;stdshade(IKGaitCycle',.1,'r');
