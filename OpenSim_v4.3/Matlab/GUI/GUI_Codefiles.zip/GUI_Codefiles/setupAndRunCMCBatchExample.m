function setupAndRunCMCBatchExample(source, destination)
%% Now Copy the relvenat xml file for this person.

results_folder = fullfile(destination,'CMCResults\');
setupfiles_folder = fullfile(destination,'CMCSetup\');
copyfile(source, setupfiles_folder)

modelFile = ' subject01_simbody_scaled';
model_folder = fullfile(destination,'ScaledModel\');

import org.opensim.modeling.*
subjectNumber = 'subject01';

genericSetupForAn = fullfile(setupfiles_folder, ['CMC_Setup.xml']);

CMCanalyzeTool = CMCTool(genericSetupForAn);
CMCanalyzeTool.setDesiredKinematicsFileName('3DGaitModel2354_Kinematics_q.sto'); 
CMCanalyzeTool.setExternalLoadsFileName('subject01_walk1_grf.xml');
CMCanalyzeTool.setStartTime(0.76);
CMCanalyzeTool.setFinalTime(1.6);
CMCanalyzeTool.setResultsDir(results_folder);
CMCanalyzeTool.run();
cd(results_folder)
end
