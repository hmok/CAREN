% [gait evbents, stride_length, step_length, timings, �,trc, 
% mot, MoS, CoM, CoP, other_stablity_measures, OpenSim_outcomes,
% Muscle_EMG, Brian_Activity, Eye_motion, etc  ] = Biomech_CAREN_Functions(c3dfiles (EMG), filtering, InertiaCompe, Inputs_DFLow, EEG, etc �)
%% clean up data
% manula that we have to do for any study
% date, numbering, type of trial
% dealing with nans and tiral did nowork we have no data exclude...

%% read c3d into OpenSim format (trc and mot, EMG) we should think of getting EMG later

% is it valide?

%% DFLOW (velocity, performance, etc, platform motions)
% how can we validaet
%% Synch combine

%% postprocessing Gait parametrss e.g. gait events, step lenght all..
% 

%% postprocessing Stabikity..based in this paper: Assessing the stability of human locomotion : a review of current measures 2013
% stability measures MoS, COm cop , etc their speed 


%% Singlas including EEG 


%% signals EMG, filtering, retifying..


%% run OpenSim  
% 1. Scaling (manual)
% 1.1. Checking
% 2. IK, ID, ...
% 2.1 is this correct mode

%% finally analyses
%lets create a big matrix data based  incling allthe outcomes.
% tables that tell us all them naming, trial, label.




