%% Codes and what they do and how to use them

%% Code Directory for me (Hossein)

mfiles = 'C:\Users\pc\.OpenSim\4.3\Code\Matlab';
addpath(mfiles)
%% Data_Collection_OpenSim.m
Data_Collection_OpenSim

%% CoM.m

%% gaitUtils.m

%% c3dExportLoop.m


%% cal_mos.m

%% createDFLOWVelocity.m

%% dflow.m

%% Gait_events.m

%% gaitEventsTRC.m


%% grfGaitEvent.m

%% HeelStrikeDetection.m


%% OpenSimMatlabAPI.m

%% osimTableFromStruct.m

%% osimTableFromStructnew.m

%% ReadTRCandplot.m

%% runOpensim.m

%% setupAndRunAnalyzeBatchExample.m


%% setupAndRunIDBatchExample.m

%% setupAndRunIKBatchExample.m

%% setupAndRunSOBatchExample.m

%% simpleOptimizerExample.m

%% Visualization_Data_OpenSim.m


%% simpleOptimizerObjectiveFunction.m

%% smooth.m

%% strengthScaler.m

%% trcGaitEvents.m

%% trialsList.m

%% TugOfWar_CompleteRunVisualize.m

%% wiringInputsAndOutputsWithTableReporter.m

%% 


%% 

%% 

%% 

%% 

%% 

%% 

%% 

%% 

%% 

%% 

%% 

%% 











