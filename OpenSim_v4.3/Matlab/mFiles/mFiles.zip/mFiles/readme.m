% readme to do for C3D to OpenSim muslce etc
%% %% run Scale, IK, ID, SO, GRF dont seem to be working in ID and SO
% I locked mtp, subtalar, and lumbar DOFs be mindful of it. give to others
% to make it more effective as we go
%% Procedure c3d to OpenSim and analyzes
% 0. have a backp for all the data somehwere else both onedrive and also
% HDD then manuplaate or do analyses on a copy of them...
% 1. first c3dexport is being used C:\Users\mhossein\Documents\OpenSim\4.0\Code\Matlab\runOpensim.m
% This file takes the folder of c3ds and bring them in the same place as trc and mot
% 2.also add th followng folders for analyses: AnalyzeResults,
% AnalyzeSetup, GRFResults, IDResults, IKResults, RRAResults, SOResults,
% CMCResults



% So far I can run Ik ID, So etc in a loop for all trial so one big issue is filtering trc and mot files in many cycles
%% Things to be done:
% 1. filtering trc and mot
% 2. Events during walking etc foot strikFS 
% 3. find event that perturb happns for some I have 
% 4. 

