function setupAndRunFDBatchExample(source, destination)
%% Now Copy the relvenat xml file for this person.

results_folder = fullfile(destination,'\FDResults\');
setupfiles_folder = fullfile(destination,'\FDSetup\');
sourceloc = strcat(source,'\FDXMLs_TargetSearch\');
copyfile(sourceloc, setupfiles_folder)

modelFile = 'subject01_simbody_scaled';
model_folder = fullfile(destination,'ScaledModel\');

import org.opensim.modeling.*
subjectNumber = 'subject01';

tic
genericSetupForAn = fullfile(setupfiles_folder, ['subject01_Setup_Forward.xml']);

FDanalyzeTool = ForwardTool(genericSetupForAn);
FDanalyzeTool.setExternalLoadsFileName('subject01_walk1_grf.xml');
FDanalyzeTool.setStartTime(0.83);
FDanalyzeTool.setFinalTime(1.08);
FDanalyzeTool.setResultsDir(results_folder);
FDanalyzeTool.run();
cd(results_folder)
toc
end
